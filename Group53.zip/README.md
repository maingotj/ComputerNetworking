# ComputerNetworking

## Members

Jonathan Maingot

Andres Martinez

Bradley Meyer

## how to compile

Make sure to have a sample Common.cfg and PeerInfo.cfg for the program to read

use the command java peerProcess peerID

switch the peerID with a peerID present in the PeerInfo.cfg
